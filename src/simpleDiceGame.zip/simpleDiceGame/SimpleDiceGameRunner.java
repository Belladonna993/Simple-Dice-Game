package simpleDiceGame;

public class SimpleDiceGameRunner {

	public static void main(String[] args) {
		SimpleDiceGameController go = new SimpleDiceGameController();
		Rules.displayRules();
		go.setRounds();
		go.playGame();
		go.displayFinalScore();

	}

}
